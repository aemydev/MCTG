﻿namespace MonsterCardTradingGame.Utility.Json
{
    public class DeckJson
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string[] Cards { get; set; }
    }
}
